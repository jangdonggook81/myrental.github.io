$(function(){
    /* header footer load */
    $("#header").load("./include/header.html", function(response, status, xhr) {
        if (status == "error") {
          console.error("Error loading external HTML:", xhr.status, xhr.statusText);
        }
      });
    $("#footer").load("./include/footer.html", function(response, status, xhr) {
        if (status == "error") {
            console.error("Error loading external HTML:", xhr.status, xhr.statusText);
        }
    });

    
})//$ end




$(document).ready(function() {
  $('.main-menu > li').hover(
    function() {
        $(this).children('.sub-menu').stop(true, true).slideDown(200);
    },
    function() {
        $(this).children('.sub-menu').stop(true, true).slideUp(200);
    }
);
});


/* 모달팝업관련 */
function ModalPopup(selector,zindex){
  let _this = this;
  this.pop_index = 0; // 팝업몇개
  this.index = zindex;
  this.$sel = $(selector);
  this.$sel.find(".close").click(function(){
    _this.close();
  })
  
}
ModalPopup.prototype.open = function(){
  $("body").addClass("modal-open")
  $(this.$sel).css({"display":"block" , "z-index" : this.index  + 1});
  this.modal_bg_make();
}
ModalPopup.prototype.close = function(){
  $("body").removeClass("modal-open")
  $(this.$sel).css({"display":"none"});
  
  //console.log(".modal-bg-"+(this.index-1))
  $(".modal-bg-"+(this.index-1)).remove();

}
ModalPopup.prototype.modal_bg_make = function(){	
  let _this = this;		
  $("body").append('<div class="modal-bg modal-bg-'+this.index+'" style="z-index:'+ this.index +'"><div>')
  this.index+=1;
}

// 레이어 외부 클릭 닫기
$(document).mouseup(function (e){
  let LayerPopup = $(".pop_inner");
  let	clicked = $(e.target);
  if(LayerPopup.has(e.target).length === 0){
    clicked.find('.close').click();
  }
});